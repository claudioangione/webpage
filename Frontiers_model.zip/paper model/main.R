####################
## Model and experiments from
## Taffi et al.
## Bioremediation in marine ecosystems: a computational study combining ecological modelling and flux balance analysis
## Marine Systems Biology, Frontiers in Genetics
####################

############
# PART 1
############
#import packages and scripts
source("r_scripts/imports.R")
#build and estimate trophic network
trophicModel<-estimateAndProcessTrophicModel()
#build and estimate contaminant network. writes reaction-based encoding of food-web
contaminantModel<-estimateAndProcessContaminantModel(trophicModel$res_trophic,
                                                     trophicModel$LIMmodel_trophic,
                                                     trophicModel$res_TL)


############
# PART 2
############

#requires food webs after bioremediation as computed through matlab scripts
#computes bioconcentrations, FBCs and exports tables for circos tableviewer (Fig 4)
remediatedModel<-processBioremediationNetworks(trophicModel$res_trophic, 
                                               contaminantModel$res_contaminant, 
                                               trophicModel$res_TL)

#Fig 5 plots
levelplots<-plotNetworksBioremediation(remediatedModel)
print(levelplots$plota)
print(levelplots$plotb)
print(levelplots$plotc)
print(levelplots$plotd)
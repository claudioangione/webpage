%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Add reaction-based encoding of food web in FBA model
%%% fbamodel: input model
%%% conversionFactor (optional): for converting units of PCBs flows into FBA units
%%% fbamodel_FW: updated FBA model
%%% fw_rxns: cell array with reactions parsed from file
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [fbamodel_FW,fw_rxns] = add_FW_reactions(fbamodel,conversionFactor)
if(nargin<2)
    molarMassBiph=154.21;
    hoursPerYear=24*365.25;
    %conversionFactor=1/(hoursPerYear*molarMassBiph);
    %we increase by a factor 1000 in order to avoid numerical errors
    conversionFactor=1000/(hoursPerYear*molarMassBiph);
end
fbamodel_FW=fbamodel;
rnxIdx=length(fbamodel_FW.rxns);
fw_rxns=csv2cell('encoded_FW.csv','fromfile');
for i=2:size(fw_rxns,1)
    rnxIdx=rnxIdx+1;
    %add reaction from table
    fbamodel_FW = addReaction(fbamodel_FW,fw_rxns{i,2},fw_rxns{i,3});
    fbamodel_FW.rev(rnxIdx)=0;
    
    fbamodel_FW.lb(rnxIdx)=str2double(fw_rxns{i,4})*conversionFactor;
    fbamodel_FW.ub(rnxIdx)=str2double(fw_rxns{i,5})*conversionFactor;
  
    fbamodel_FW.subSystems{rnxIdx}='Food Web';
    
end

%zero the original external PCBs uptake of P.putida
fbamodel_FW.lb(1072)=0;
%zero uptake fluxes of 4-Chlorobiphenyl and Carbazole (the behaviour it's
%equivalent if considering bioremediation of just Biphenyl)
fbamodel_FW.ub(1454)=0;
fbamodel_FW.ub(1456)=0;

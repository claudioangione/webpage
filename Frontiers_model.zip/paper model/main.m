%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Model and experiments from
%% Taffi et al.
%% Bioremediation in marine ecosystems: a computational study combining ecological modelling and flux balance analysis
%% Marine Systems Biology, Frontiers in Genetics
%%%%%%%%%%%%%%%%%%%%%%%%%%

function main()
addpath(genpath('matlab_scripts'));

load 'iJN746_Pputida+upperPathway.mat'
%cost vector for maximizing growth
biomass_cost = fbamodel_ppu_upperPath.c;

%cost vector for maximizing PCBs uptake
pcbs_cost=zeros(length(fbamodel_ppu_upperPath.c),1);
pcbs_cost(1072)=-1;

%cost vector for maximizing toluene uptake
toluene_cost=zeros(length(fbamodel_ppu_upperPath.c),1);
toluene_cost(434)=-1;

%cost vector for maximizing the sum of toluene and PCBs
pcbs_toluene_cost=zeros(length(fbamodel_ppu_upperPath.c),1);
pcbs_toluene_cost(434)=-1;
pcbs_toluene_cost(1072)=-1;


%compute optimal biomass production
[v_1, v_2, opt_bio, o_2] = flux_balance_bilevel(fbamodel_ppu_upperPath, biomass_cost,biomass_cost);

%compute optimal PCBs uptake
[v_1, v_2, opt_pcb, o_2] = flux_balance_bilevel(fbamodel_ppu_upperPath, pcbs_cost, pcbs_cost);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Fig. 3a
%%% plot biomass production (L2) at 
%%% varying PCBs max uptake rate (L1)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
PCBs_uptakes=-10:0.1:0;
results3a=zeros(length(PCBs_uptakes),2);
for i=1:length(PCBs_uptakes)
    fbamodel_tmp=fbamodel_ppu_upperPath;
    %limit PCBs uptake
    fbamodel_tmp.lb(1072)=PCBs_uptakes(i);
    [v_1, v_2, o_1, o_2] = flux_balance_bilevel(fbamodel_tmp, pcbs_cost, biomass_cost);
    results3a(i,:) = [o_1, o_2];
end
plotfig3a(PCBs_uptakes,results3a(:,2));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Fig. 3b
%%% plot biomass production (L1) and 
%%% PCBs uptake (L2) at varying
%%% oxygen uptake rates
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ox_uptakes=-20:0.1:0;
results3b=zeros(length(ox_uptakes),2);
for i=1:length(ox_uptakes)
    fbamodel_tmp=fbamodel_ppu_upperPath;
    %limit oxygen uptake
    fbamodel_tmp.lb(416)=ox_uptakes(i);
    [v_1, v_2, o_1, o_2] = flux_balance_bilevel(fbamodel_tmp, biomass_cost, pcbs_cost);
    results3b(i,:) = [o_1, o_2];
end
plotfig3b(ox_uptakes,[results3b(:,1)/opt_bio,results3b(:,2)/opt_pcb]);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Fig. 3c
%%% phenotypic phase plane plot at
%%% varying PCBs and toluene uptakes
%%% L1: PCBs+toluene; L2: biomass
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%compute the PCB/toluene front
toluene_uptakes=-20:0.1:0;
toluene_pcbs_front=zeros(length(toluene_uptakes),2);
for i=1:length(toluene_uptakes)
    fbamodel_tmp=fbamodel_ppu_upperPath;
    fbamodel_tmp.lb(434)=toluene_uptakes(i);
    [v_1, v_2, o_1, o_2] = flux_balance_bilevel(fbamodel_tmp, toluene_cost, pcbs_cost);
    toluene_pcbs_front(i,:) = [o_1, o_2];
end
plot_Toluene_PCBs_front(toluene_pcbs_front(:,1),toluene_pcbs_front(:,2));

% use a smaller resolution to have faster results in the phenotypic
% analysis
%resolution = 0.1;
resolution = 0.5;
[pcbs,biom] = phenotypic_phase(fbamodel_ppu_upperPath,1072,-10:resolution:0,434,-20:resolution:0,pcbs_toluene_cost,biomass_cost);
plotfig3c(biom/opt_bio,resolution)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Integration of food web with P. putida metabolism
%%%
%%% Requires the reaction-based encoding of the food web (encoded_FW.csv) 
%%% computed with R scripts
%%%
%%% Computes and writes to file the food webs after bioremediation of detritus
%%% and of water compartments, at different efficiencies (from 0% to 100%
%%% by 2%)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[fbamodel_ppu_upperPath_fw,FW_reactions] = add_FW_reactions(fbamodel_ppu_upperPath);
%set the bioremediation objective (remediation of Biphenyl metabolite)
biorem_obj=zeros(length(fbamodel_ppu_upperPath_fw.c),1);
biorem_obj(1455)=1;

%bioremediation from detritus groups (max flux 3)
flows_det=0:0.06:3;
fbamodel_ppu_upperPath_fw_tmp=fbamodel_ppu_upperPath_fw;
%excludes bioremediation fluxes of water
fbamodel_ppu_upperPath_fw_tmp.ub(1458)=0;
%loop over increasing bioremediation efficiences
for i= 1:length(flows_det)
    fbamodel_ppu_upperPath_fw_tmp.ub(1460)=flows_det(i);
    [v_1, v_2, o_1, o_2] = flux_balance_bilevel(fbamodel_ppu_upperPath_fw_tmp, biorem_obj, biorem_obj);
    %write contaminant fluxes in remediated network to file
    exportFWFluxes(FW_reactions,v_1(1075:length(v_1)),sprintf('./fluxes_biorem/FW_fluxes_detritus_%d.csv',i));
end

%bioremediation from detritus groups (max 2.443085)
flows_water=0:0.049:2.45;
fbamodel_ppu_upperPath_fw_tmp=fbamodel_ppu_upperPath_fw;
fbamodel_ppu_upperPath_fw_tmp.ub(1460)=0;%zero flows from detritus
%loop over increasing bioremediation efficiences
for i= 1:length(flows_water)
    fbamodel_ppu_upperPath_fw_tmp.ub(1458)=flows_water(i);
    [v_1, v_2, o_1, o_2] = flux_balance_bilevel(fbamodel_ppu_upperPath_fw_tmp, biorem_obj, biorem_obj);
    %write contaminant fluxes in remediated network to file
    exportFWFluxes(FW_reactions,v_1(1075:length(v_1)),sprintf('./fluxes_biorem/FW_fluxes_water_%d.csv',i));
end


